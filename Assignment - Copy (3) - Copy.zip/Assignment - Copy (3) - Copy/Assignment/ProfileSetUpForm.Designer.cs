﻿namespace Assignment
{
    partial class ProfileSetUpForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTellUsAbtUrself = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.lblLastName = new System.Windows.Forms.Label();
            this.txtTargetCalories = new System.Windows.Forms.TextBox();
            this.lblTargetCalories = new System.Windows.Forms.Label();
            this.txtBodyWeight = new System.Windows.Forms.TextBox();
            this.lblBodyWeight = new System.Windows.Forms.Label();
            this.cmdContinue = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTellUsAbtUrself
            // 
            this.lblTellUsAbtUrself.AutoSize = true;
            this.lblTellUsAbtUrself.Font = new System.Drawing.Font("Perpetua Titling MT", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTellUsAbtUrself.ForeColor = System.Drawing.Color.White;
            this.lblTellUsAbtUrself.Location = new System.Drawing.Point(175, 38);
            this.lblTellUsAbtUrself.Name = "lblTellUsAbtUrself";
            this.lblTellUsAbtUrself.Size = new System.Drawing.Size(445, 36);
            this.lblTellUsAbtUrself.TabIndex = 0;
            this.lblTellUsAbtUrself.Text = "Tell Us About Yourself";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstName.ForeColor = System.Drawing.Color.White;
            this.lblFirstName.Location = new System.Drawing.Point(126, 133);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(92, 23);
            this.lblFirstName.TabIndex = 1;
            this.lblFirstName.Text = "First Name";
            // 
            // txtFirstName
            // 
            this.txtFirstName.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFirstName.Location = new System.Drawing.Point(524, 126);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(175, 30);
            this.txtFirstName.TabIndex = 2;
            // 
            // txtLastName
            // 
            this.txtLastName.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLastName.Location = new System.Drawing.Point(524, 180);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(175, 30);
            this.txtLastName.TabIndex = 4;
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLastName.ForeColor = System.Drawing.Color.White;
            this.lblLastName.Location = new System.Drawing.Point(127, 183);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(91, 23);
            this.lblLastName.TabIndex = 3;
            this.lblLastName.Text = "Last Name";
            // 
            // txtTargetCalories
            // 
            this.txtTargetCalories.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTargetCalories.Location = new System.Drawing.Point(524, 296);
            this.txtTargetCalories.Name = "txtTargetCalories";
            this.txtTargetCalories.Size = new System.Drawing.Size(175, 30);
            this.txtTargetCalories.TabIndex = 8;
            // 
            // lblTargetCalories
            // 
            this.lblTargetCalories.AutoSize = true;
            this.lblTargetCalories.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTargetCalories.ForeColor = System.Drawing.Color.White;
            this.lblTargetCalories.Location = new System.Drawing.Point(40, 303);
            this.lblTargetCalories.Name = "lblTargetCalories";
            this.lblTargetCalories.Size = new System.Drawing.Size(262, 23);
            this.lblTargetCalories.TabIndex = 7;
            this.lblTargetCalories.Text = "Target Calories You Want to Burn";
            // 
            // txtBodyWeight
            // 
            this.txtBodyWeight.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBodyWeight.Location = new System.Drawing.Point(524, 238);
            this.txtBodyWeight.Name = "txtBodyWeight";
            this.txtBodyWeight.Size = new System.Drawing.Size(175, 30);
            this.txtBodyWeight.TabIndex = 6;
            // 
            // lblBodyWeight
            // 
            this.lblBodyWeight.AutoSize = true;
            this.lblBodyWeight.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBodyWeight.ForeColor = System.Drawing.Color.White;
            this.lblBodyWeight.Location = new System.Drawing.Point(111, 245);
            this.lblBodyWeight.Name = "lblBodyWeight";
            this.lblBodyWeight.Size = new System.Drawing.Size(107, 23);
            this.lblBodyWeight.TabIndex = 5;
            this.lblBodyWeight.Text = "Body Weight";
            // 
            // cmdContinue
            // 
            this.cmdContinue.AutoSize = true;
            this.cmdContinue.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdContinue.Location = new System.Drawing.Point(344, 352);
            this.cmdContinue.Name = "cmdContinue";
            this.cmdContinue.Padding = new System.Windows.Forms.Padding(20, 8, 20, 8);
            this.cmdContinue.Size = new System.Drawing.Size(130, 49);
            this.cmdContinue.TabIndex = 9;
            this.cmdContinue.Text = "Continue";
            this.cmdContinue.UseVisualStyleBackColor = true;
            this.cmdContinue.Click += new System.EventHandler(this.cmdContinue_Click);
            // 
            // ProfileSetUpForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(79)))));
            this.ClientSize = new System.Drawing.Size(782, 413);
            this.Controls.Add(this.cmdContinue);
            this.Controls.Add(this.txtTargetCalories);
            this.Controls.Add(this.lblTargetCalories);
            this.Controls.Add(this.txtBodyWeight);
            this.Controls.Add(this.lblBodyWeight);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.lblLastName);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.lblFirstName);
            this.Controls.Add(this.lblTellUsAbtUrself);
            this.Name = "ProfileSetUpForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ProfileSetUpForm";
            //this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ProfileSetUpForm_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTellUsAbtUrself;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.TextBox txtTargetCalories;
        private System.Windows.Forms.Label lblTargetCalories;
        private System.Windows.Forms.TextBox txtBodyWeight;
        private System.Windows.Forms.Label lblBodyWeight;
        private System.Windows.Forms.Button cmdContinue;
    }
}