﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Topic5Test
{
    public partial class Form1 : Form
    {
        Person me;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            me = new Person();

        }

        private void cmdStore_Click(object sender, EventArgs e)
        {
            String name = txtName.Text;
            int age = Int16.Parse(txtAge.Text);

            me.Name = name;
            me.Age = age;
        }

        private void cmdDisplay_Click(object sender, EventArgs e)
        {
            txtYouTyped.Text = me.Name + " " + me.Age;
        }
    }
}
